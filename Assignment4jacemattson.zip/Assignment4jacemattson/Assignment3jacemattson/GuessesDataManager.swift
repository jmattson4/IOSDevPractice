//
//  GuessesDataManager.swift
//  Assignment3jacemattson
//
//  Created by Jace Mattson on 2019-03-13.
//  Copyright © 2019 Jace Mattson. All rights reserved.
//

import UIKit
import CoreData
import Foundation

class GuessesDataManager : NSManagedObject
{
    @NSManaged var guess: Int?
    
}
